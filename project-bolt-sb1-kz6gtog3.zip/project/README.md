# AcuFlow - Tinnitus Relief App

AcuFlow is a comprehensive web application designed to help users manage and find relief from tinnitus symptoms through sound therapy, meditation, and lifestyle guidance.

## Features

- 🎵 Sound Therapy Gallery with various noise types and nature sounds
- 📝 Personal Tinnitus Diary for tracking symptoms
- 🧘‍♀️ Meditation and relaxation techniques
- 📚 Educational resources and research library
- 👥 Community support and discussion forums
- 🥗 Nutrition guidance for tinnitus management
- 📊 Personal dashboard for progress tracking
- 💎 Premium features with subscription options

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- Supabase for backend
- Zustand for state management
- Lucide React for icons

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up environment variables:
   Create a `.env` file with your Supabase credentials:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```

## Project Structure

```
src/
├── components/     # Reusable UI components
├── pages/         # Page components
├── store/         # Zustand store configurations
├── styles/        # Global styles and CSS
└── lib/           # Utility functions and configurations
```

## Features in Detail

### Sound Gallery
- White, pink, and brown noise
- Nature sounds (rain, ocean, forest)
- Meditation and binaural beats
- Custom sound mixing (Premium)

### Tinnitus Diary
- Daily symptom tracking
- Mood and intensity logging
- Progress visualization
- Export functionality

### Community Features
- Discussion forums
- Success stories
- Support groups
- Expert advice

### Nutrition Guide
- Tinnitus-friendly recipes
- Dietary recommendations
- Meal planning assistance
- Nutritional research

## License

MIT License

## Live Demo

Visit [AcuFlow](https://acuflow.netlify.app) to see the live application.