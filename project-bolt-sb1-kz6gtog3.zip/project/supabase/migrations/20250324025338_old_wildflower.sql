/*
  # Create diary entries table

  1. New Tables
    - `diary_entries`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `content` (text)
      - `mood` (integer)
      - `user_id` (uuid, references auth.users)

  2. Security
    - Enable RLS on `diary_entries` table
    - Add policies for authenticated users to:
      - Read their own entries
      - Create new entries
      - Update their own entries
      - Delete their own entries
*/

CREATE TABLE IF NOT EXISTS diary_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  content text NOT NULL,
  mood integer NOT NULL CHECK (mood >= 1 AND mood <= 10),
  user_id uuid REFERENCES auth.users NOT NULL
);

ALTER TABLE diary_entries ENABLE ROW LEVEL SECURITY;

-- Policy to allow users to read their own entries
CREATE POLICY "Users can read own diary entries"
  ON diary_entries
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policy to allow users to create their own entries
CREATE POLICY "Users can create diary entries"
  ON diary_entries
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policy to allow users to update their own entries
CREATE POLICY "Users can update own diary entries"
  ON diary_entries
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policy to allow users to delete their own entries
CREATE POLICY "Users can delete own diary entries"
  ON diary_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);