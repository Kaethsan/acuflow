/*
  # Add saved recipes functionality

  1. New Tables
    - `saved_recipes`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references users.id)
      - `recipe_id` (text, not null)
      - `created_at` (timestamp with time zone)
      - `notes` (text)

  2. Security
    - Enable RLS on `saved_recipes` table
    - Add policies for users to manage their saved recipes
*/

CREATE TABLE IF NOT EXISTS saved_recipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  recipe_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  notes text,
  UNIQUE(user_id, recipe_id)
);

ALTER TABLE saved_recipes ENABLE ROW LEVEL SECURITY;

-- Allow users to read their own saved recipes
CREATE POLICY "Users can read own saved recipes"
  ON saved_recipes
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow users to save new recipes
CREATE POLICY "Users can save recipes"
  ON saved_recipes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Allow users to delete their saved recipes
CREATE POLICY "Users can delete own saved recipes"
  ON saved_recipes
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow users to update their saved recipes (notes)
CREATE POLICY "Users can update own saved recipes"
  ON saved_recipes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);