import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Account from './pages/Account';
import SoundGallery from './pages/SoundGallery';
import Library from './pages/Library';
import Community from './pages/Community';
import Subscription from './pages/Subscription';
import Nutrition from './pages/Nutrition';
import Dashboard from './pages/Dashboard';
import { useThemeStore } from './store/themeStore';
import './styles/neumorphic.css';

function App() {
  const { isDark } = useThemeStore();

  // Apply theme immediately and on changes
  useEffect(() => {
    const applyTheme = () => {
      document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
    };

    // Apply theme immediately
    applyTheme();

    // Re-apply theme when visibility changes (tab switching)
    document.addEventListener('visibilitychange', applyTheme);

    return () => {
      document.removeEventListener('visibilitychange', applyTheme);
    };
  }, [isDark]);

  return (
    <Router>
      <div className="min-h-screen transition-colors duration-300">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/account" element={<Account />} />
            <Route path="/sound-gallery" element={<SoundGallery />} />
            <Route path="/library" element={<Library />} />
            <Route path="/community" element={<Community />} />
            <Route path="/subscription" element={<Subscription />} />
            <Route path="/nutrition" element={<Nutrition />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;