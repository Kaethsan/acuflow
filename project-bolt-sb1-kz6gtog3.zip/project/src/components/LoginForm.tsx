import React from 'react';
import { LogIn, Mail, Lock } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

const LoginForm = () => {
  const { login } = useAuthStore();

  const handleQuickLogin = () => {
    login();
  };

  return (
    <div className="neu-flat p-8 max-w-md mx-auto">
      <h2 className="text-2xl font-semibold mb-6 text-center">Welcome to AcuFlow</h2>
      
      <form className="space-y-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium">Email</label>
          <div className="neu-pressed p-2 flex items-center">
            <Mail className="h-5 w-5 text-accent mx-2" />
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 p-2 bg-transparent border-none outline-none"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium">Password</label>
          <div className="neu-pressed p-2 flex items-center">
            <Lock className="h-5 w-5 text-accent mx-2" />
            <input
              type="password"
              placeholder="Enter your password"
              className="flex-1 p-2 bg-transparent border-none outline-none"
            />
          </div>
        </div>

        <button
          type="button"
          onClick={handleQuickLogin}
          className="w-full neu-button p-4 text-accent hover:text-primary-dark transition-colors flex items-center justify-center gap-2"
        >
          <LogIn className="h-5 w-5" />
          <span>Quick Login (Demo)</span>
        </button>
      </form>
    </div>
  );
};

export default LoginForm;