import React, { useState } from 'react';
import { Send, Facebook, Twitter, Slack, Github, Linkedin } from 'lucide-react';

const SubscribeForm = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle subscription logic here
    console.log('Subscribing:', email);
    setEmail('');
  };

  return (
    <div className="neu-flat p-8 max-w-md mx-auto">
      <h2 className="text-xl font-semibold mb-6">Subscribe</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="neu-pressed p-2">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="w-full p-3 bg-transparent border-none outline-none"
            required
          />
        </div>
        
        <button
          type="submit"
          className="w-full neu-button p-4 text-accent hover:text-primary-dark transition-colors flex items-center justify-center gap-2"
        >
          <span>Subscribe</span>
          <Send className="h-4 w-4" />
        </button>
      </form>

      <div className="mt-8">
        <p className="text-sm text-gray-600 mb-4">Follow us on our socials</p>
        <div className="flex justify-center gap-4">
          {[
            { Icon: Facebook, label: 'Facebook' },
            { Icon: Twitter, label: 'Twitter' },
            { Icon: Slack, label: 'Slack' },
            { Icon: Github, label: 'Github' },
            { Icon: Linkedin, label: 'LinkedIn' }
          ].map(({ Icon, label }) => (
            <button
              key={label}
              className="neu-button p-3 text-accent hover:text-primary-dark transition-colors"
              aria-label={label}
            >
              <Icon className="h-5 w-5" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubscribeForm;