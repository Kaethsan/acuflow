import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Book, Plus, Edit2, Trash2, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';

interface DiaryEntry {
  id: string;
  created_at: string;
  content: string;
  mood: number;
  user_id: string;
}

const DiarySection = () => {
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [newEntry, setNewEntry] = useState('');
  const [mood, setMood] = useState(5);
  const { user } = useAuthStore();

  useEffect(() => {
    fetchEntries();
  }, []);

  const fetchEntries = async () => {
    const { data, error } = await supabase
      .from('diary_entries')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching entries:', error);
    } else {
      setEntries(data || []);
    }
  };

  const addEntry = async () => {
    if (!newEntry.trim()) return;

    const { error } = await supabase.from('diary_entries').insert([
      {
        content: newEntry,
        mood,
        user_id: user?.id,
      },
    ]);

    if (error) {
      console.error('Error adding entry:', error);
    } else {
      setNewEntry('');
      setMood(5);
      fetchEntries();
    }
  };

  const deleteEntry = async (id: string) => {
    const { error } = await supabase.from('diary_entries').delete().eq('id', id);

    if (error) {
      console.error('Error deleting entry:', error);
    } else {
      fetchEntries();
    }
  };

  const exportEntries = () => {
    const formattedEntries = entries.map(entry => ({
      date: format(new Date(entry.created_at), 'PPP'),
      content: entry.content,
      mood: `${entry.mood}/10`
    }));

    const csvContent = [
      ['Date', 'Content', 'Tinnitus Level'],
      ...formattedEntries.map(entry => [entry.date, entry.content, entry.mood])
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `tinnitus-diary-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="mt-8">
      <div className="neu-pressed p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Book className="text-accent" />
            Tinnitus Diary
          </h2>
          <button
            onClick={exportEntries}
            className="neu-button p-3 text-accent hover:text-primary-dark flex items-center gap-2"
            title="Export diary entries"
          >
            <Download className="h-5 w-5" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>

        <div className="space-y-6">
          <div className="neu-flat p-4">
            <textarea
              value={newEntry}
              onChange={(e) => setNewEntry(e.target.value)}
              placeholder="How are you feeling today? Record your tinnitus experience..."
              className="w-full p-4 neu-pressed rounded-lg resize-none h-32"
            />
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-4">
                <span className="text-sm">Tinnitus Level:</span>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={mood}
                  onChange={(e) => setMood(Number(e.target.value))}
                  className="w-32"
                />
                <span className="text-sm">{mood}/10</span>
              </div>
              <button
                onClick={addEntry}
                className="neu-button p-3 text-accent hover:text-primary-dark"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {entries.map((entry) => (
              <div key={entry.id} className="neu-flat p-4">
                <div className="flex justify-between items-start mb-2">
                  <p className="text-sm text-gray-600">
                    {format(new Date(entry.created_at), 'PPP')}
                  </p>
                  <div className="flex gap-2">
                    <button className="neu-button p-2 text-accent hover:text-primary-dark">
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteEntry(entry.id)}
                      className="neu-button p-2 text-accent hover:text-primary-dark"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <p className="mb-2">{entry.content}</p>
                <div className="flex items-center gap-2">
                  <span className="text-sm">Tinnitus Level:</span>
                  <span className="text-sm font-semibold">{entry.mood}/10</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiarySection;