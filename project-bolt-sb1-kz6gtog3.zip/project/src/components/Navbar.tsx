import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Ear, User, Music, BookOpen, Crown, Utensils, Users, Moon, Sun } from 'lucide-react';
import { useThemeStore } from '../store/themeStore';

const Navbar = () => {
  const location = useLocation();
  const [isLogoPressed, setIsLogoPressed] = useState(false);
  const { isDark, toggleTheme } = useThemeStore();
  
  const isActive = (path: string) => location.pathname === path;
  
  const navItems = [
    { path: '/account', icon: User, label: 'Account' },
    { path: '/sound-gallery', icon: Music, label: 'Sounds' },
    { path: '/library', icon: BookOpen, label: 'Library' },
    { path: '/community', icon: Users, label: 'Community' },
    { path: '/nutrition', icon: Utensils, label: 'Nutrition' },
    { path: '/subscription', icon: Crown, label: 'Subscribe' },
  ];

  return (
    <nav className="neu-flat p-4 mb-8">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center justify-between">
            <Link 
              to="/" 
              className={`text-2xl font-bold ${isLogoPressed ? 'text-primary-dark' : 'text-accent'} 
                flex items-center gap-2 neu-button p-3 rounded-lg w-fit transition-all duration-200
                active:neu-pressed active:text-primary-dark`}
              onMouseDown={() => setIsLogoPressed(true)}
              onMouseUp={() => setIsLogoPressed(false)}
              onMouseLeave={() => setIsLogoPressed(false)}
            >
              <Ear className="h-8 w-8" />
              AcuFlow
            </Link>
            <button
              onClick={toggleTheme}
              className="neu-button p-3 text-accent md:hidden"
              aria-label="Toggle theme"
            >
              {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>
          <div className="flex flex-wrap md:flex-nowrap justify-start md:justify-end gap-3 items-center">
            {navItems.map(({ path, icon: Icon, label }) => (
              <Link
                key={path}
                to={path}
                className={`flex items-center gap-2 p-3 rounded-lg transition-all min-w-[100px] justify-center
                  ${isActive(path) 
                    ? 'neu-pressed text-accent font-medium' 
                    : 'neu-button hover:text-accent'
                  }`}
              >
                <Icon size={20} />
                <span className="text-sm">{label}</span>
              </Link>
            ))}
            <button
              onClick={toggleTheme}
              className="neu-button p-3 text-accent hidden md:flex"
              aria-label="Toggle theme"
            >
              {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;