import React from 'react';
import { BookOpen, Star, Clock, Book, ShoppingCart, Download, ExternalLink, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Article {
  id: string;
  title: string;
  description: string;
  author: string;
  readTime: string;
  category: 'featured' | 'recent' | 'research';
  link: string;
}

const articles: Article[] = [
  {
    id: '1',
    title: 'Understanding Tinnitus: A Comprehensive Guide',
    description: 'Latest research findings on tinnitus causes, symptoms, and evidence-based treatment approaches.',
    author: 'Dr. Emily Chen',
    readTime: '12 min read',
    category: 'featured',
    link: '/library/understanding-tinnitus'
  },
  {
    id: '2',
    title: 'Sound Therapy: Evidence-Based Approaches',
    description: 'An in-depth analysis of clinical studies on sound therapy effectiveness for tinnitus management.',
    author: 'Dr. Michael Roberts',
    readTime: '15 min read',
    category: 'featured',
    link: '/library/sound-therapy-evidence'
  },
  {
    id: '3',
    title: 'Dietary Influences on Tinnitus Symptoms',
    description: 'New research findings on how nutrition affects tinnitus symptoms and management strategies.',
    author: 'Dr. Sarah Johnson',
    readTime: '10 min read',
    category: 'recent',
    link: '/library/dietary-influences'
  },
  {
    id: '4',
    title: 'Cognitive Behavioral Therapy for Tinnitus',
    description: 'A comprehensive look at psychological approaches to tinnitus relief and management.',
    author: 'Dr. David Wilson',
    readTime: '8 min read',
    category: 'recent',
    link: '/library/cbt-tinnitus'
  },
  {
    id: '5',
    title: 'Sleep and Tinnitus: Breaking the Cycle',
    description: 'Understanding the relationship between sleep quality and tinnitus intensity.',
    author: 'Dr. Lisa Anderson',
    readTime: '14 min read',
    category: 'research',
    link: '/library/sleep-tinnitus'
  },
  {
    id: '6',
    title: 'Stress Management Techniques for Tinnitus',
    description: 'Evidence-based strategies for managing stress-induced tinnitus symptoms.',
    author: 'Dr. James Brown',
    readTime: '11 min read',
    category: 'research',
    link: '/library/stress-management'
  }
];

const Library = () => {
  return (
    <div className="space-y-8">
      <div className="neu-flat p-8">
        <h1 className="text-3xl font-bold mb-6">Research Library</h1>
        
        <div className="space-y-8">
          {/* Books Section */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Book className="text-accent" />
              Recommended Books
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="neu-flat p-6 flex flex-col">
                <div className="flex-grow">
                  <div className="aspect-[3/4] mb-4 neu-pressed rounded-lg overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c"
                      alt="Healing Tinnitus Book Cover"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Healing Tinnitus: What Doctors won't tell you</h3>
                  <p className="text-gray-600 mb-2">By Sandra Kaethner</p>
                  <div className="flex items-center gap-2">
                    <span className="text-accent font-bold">€35.00</span>
                    <span className="text-sm text-gray-600">(Digital + Print)</span>
                  </div>
                </div>
                <div className="space-y-2 mt-4">
                  <button className="w-full neu-button p-3 flex items-center justify-center gap-2 text-accent">
                    <ShoppingCart className="h-5 w-5" />
                    Buy Now
                  </button>
                  <button className="w-full neu-button p-3 flex items-center justify-center gap-2">
                    <Download className="h-5 w-5" />
                    Preview Chapter
                  </button>
                </div>
              </div>

              <div className="neu-flat p-6 flex flex-col">
                <div className="flex-grow">
                  <div className="aspect-[3/4] mb-4 neu-pressed rounded-lg overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1553729459-efe14ef6055d"
                      alt="The Science of Silence Book Cover"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">The Science of Silence</h3>
                  <p className="text-gray-600 mb-2">By Dr. Emily Chen</p>
                  <div className="flex items-center gap-2">
                    <span className="text-accent font-bold">€29.99</span>
                    <span className="text-sm text-gray-600">(Digital)</span>
                  </div>
                </div>
                <div className="space-y-2 mt-4">
                  <button className="w-full neu-button p-3 flex items-center justify-center gap-2 text-accent">
                    <ShoppingCart className="h-5 w-5" />
                    Buy Now
                  </button>
                  <button className="w-full neu-button p-3 flex items-center justify-center gap-2">
                    <Download className="h-5 w-5" />
                    Preview Chapter
                  </button>
                </div>
              </div>

              <div className="neu-flat p-6 flex flex-col">
                <div className="flex-grow">
                  <div className="aspect-[3/4] mb-4 neu-pressed rounded-lg overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1544947950-fa07a98d237f"
                      alt="Living with Tinnitus Book Cover"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Living with Tinnitus</h3>
                  <p className="text-gray-600 mb-2">By Dr. Michael Roberts</p>
                  <div className="flex items-center gap-2">
                    <span className="text-accent font-bold">€24.99</span>
                    <span className="text-sm text-gray-600">(Digital)</span>
                  </div>
                </div>
                <div className="space-y-2 mt-4">
                  <button className="w-full neu-button p-3 flex items-center justify-center gap-2 text-accent">
                    <ShoppingCart className="h-5 w-5" />
                    Buy Now
                  </button>
                  <button className="w-full neu-button p-3 flex items-center justify-center gap-2">
                    <Download className="h-5 w-5" />
                    Preview Chapter
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Featured Articles */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Star className="text-accent" />
              Featured Articles
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {articles.filter(article => article.category === 'featured').map(article => (
                <Link
                  key={article.id}
                  to={article.link}
                  className="neu-flat p-6 group transition-all duration-300 hover:scale-[1.02]"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-semibold group-hover:text-accent transition-colors">
                      {article.title}
                    </h3>
                    <ArrowRight className="h-5 w-5 text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <p className="text-gray-600 mb-4">{article.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-accent">{article.author}</span>
                    <span className="text-gray-600">{article.readTime}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Recent Publications */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Clock className="text-accent" />
              Recent Publications
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {articles.filter(article => article.category === 'recent').map(article => (
                <Link
                  key={article.id}
                  to={article.link}
                  className="neu-flat p-6 group transition-all duration-300 hover:scale-[1.02]"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-semibold group-hover:text-accent transition-colors">
                      {article.title}
                    </h3>
                    <ArrowRight className="h-5 w-5 text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <p className="text-gray-600 mb-4">{article.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-accent">{article.author}</span>
                    <span className="text-gray-600">{article.readTime}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Research Papers */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <BookOpen className="text-accent" />
              Research Papers
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {articles.filter(article => article.category === 'research').map(article => (
                <Link
                  key={article.id}
                  to={article.link}
                  className="neu-flat p-6 group transition-all duration-300 hover:scale-[1.02]"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-semibold group-hover:text-accent transition-colors">
                      {article.title}
                    </h3>
                    <ArrowRight className="h-5 w-5 text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <p className="text-gray-600 mb-4">{article.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-accent">{article.author}</span>
                    <span className="text-gray-600">{article.readTime}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Library;