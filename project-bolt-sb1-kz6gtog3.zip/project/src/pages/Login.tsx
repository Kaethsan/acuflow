import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { supabase } from '../lib/supabase';
import { LogIn } from 'lucide-react';

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, setUser } = useAuthStore();
  const [isLoading, setIsLoading] = useState(false);

  React.useEffect(() => {
    if (user) {
      const from = (location.state as any)?.from?.pathname || '/dashboard';
      navigate(from, { replace: true });
    }
  }, [user, navigate, location]);

  const handleQuickLogin = async () => {
    setIsLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: 'test@example.com',
      password: 'test123456',
    });

    if (error) {
      // If signup fails, try to sign in instead
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email: 'test@example.com',
        password: 'test123456',
      });

      if (signInError) {
        console.error('Error:', signInError);
        setIsLoading(false);
        return;
      }

      setUser(signInData.user);
    } else {
      setUser(data.user);
    }

    setIsLoading(false);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="neu-flat p-8 w-full max-w-md text-center">
        <h1 className="text-3xl font-bold mb-8">Welcome to AcuFlow</h1>
        <button
          onClick={handleQuickLogin}
          disabled={isLoading}
          className={`neu-button w-full p-4 text-white bg-accent hover:bg-accent/90 flex items-center justify-center gap-2 ${
            isLoading ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          <LogIn className="h-5 w-5" />
          {isLoading ? 'Logging in...' : 'Quick Login'}
        </button>
        <p className="mt-4 text-sm text-gray-600">
          Click the button above to quickly access the dashboard
        </p>
      </div>
    </div>
  );
};

export default Login;