import React, { useState } from 'react';
import { Volume2, Waves, Wind, Music, Cloud, Droplets, Bird, Leaf, Heart, Play, Pause, Volume1, Volume } from 'lucide-react';

interface Sound {
  id: string;
  title: string;
  description: string;
  url: string;
  icon: React.ElementType;
  category: 'noise' | 'nature' | 'meditation';
}

const sounds: Sound[] = [
  {
    id: 'white-noise',
    title: 'White Noise',
    description: 'Pure, consistent sound across all frequencies',
    url: 'https://assets.mixkit.co/active_storage/sfx/2532/2532-preview.mp3',
    icon: Volume2,
    category: 'noise'
  },
  {
    id: 'pink-noise',
    title: 'Pink Noise',
    description: 'Balanced frequency reduction for natural comfort',
    url: 'https://assets.mixkit.co/active_storage/sfx/2533/2533-preview.mp3',
    icon: Waves,
    category: 'noise'
  },
  {
    id: 'brown-noise',
    title: 'Brown Noise',
    description: 'Deep, low-frequency focused sound',
    url: 'https://assets.mixkit.co/active_storage/sfx/2534/2534-preview.mp3',
    icon: Wind,
    category: 'noise'
  },
  {
    id: 'rain',
    title: 'Rain Sounds',
    description: 'Gentle rainfall and distant thunder',
    url: 'https://assets.mixkit.co/active_storage/sfx/2515/2515-preview.mp3',
    icon: Cloud,
    category: 'nature'
  },
  {
    id: 'ocean',
    title: 'Ocean Waves',
    description: 'Calming waves and seaside ambience',
    url: 'https://assets.mixkit.co/active_storage/sfx/2525/2525-preview.mp3',
    icon: Droplets,
    category: 'nature'
  },
  {
    id: 'forest',
    title: 'Forest Birds',
    description: 'Morning birdsong and rustling leaves',
    url: 'https://assets.mixkit.co/active_storage/sfx/2520/2520-preview.mp3',
    icon: Bird,
    category: 'nature'
  },
  {
    id: 'binaural',
    title: 'Binaural Beats',
    description: 'Frequency-specific brain wave entrainment',
    url: 'https://assets.mixkit.co/active_storage/sfx/2434/2434-preview.mp3',
    icon: Music,
    category: 'meditation'
  },
  {
    id: 'meditation',
    title: 'Zen Meditation',
    description: 'Traditional meditation bowls and flutes',
    url: 'https://assets.mixkit.co/active_storage/sfx/2435/2435-preview.mp3',
    icon: Leaf,
    category: 'meditation'
  },
  {
    id: 'ambient',
    title: 'Ambient Music',
    description: 'Soothing ambient compositions',
    url: 'https://assets.mixkit.co/active_storage/sfx/2436/2436-preview.mp3',
    icon: Heart,
    category: 'meditation'
  }
];

const SoundPlayer = ({ sound }: { sound: Sound }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  React.useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlay = async () => {
    if (audioRef.current) {
      try {
        if (isPlaying) {
          await audioRef.current.pause();
        } else {
          await audioRef.current.play();
        }
        setIsPlaying(!isPlaying);
      } catch (error) {
        console.error('Error playing audio:', error);
      }
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
    }
  };

  const handleAudioError = (e: React.SyntheticEvent<HTMLAudioElement, Event>) => {
    console.error('Audio error:', e);
    setIsPlaying(false);
  };

  const VolumeIcon = volume === 0 ? Volume : volume < 0.5 ? Volume1 : Volume2;

  return (
    <div className="neu-flat p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <sound.icon className="text-accent h-5 w-5" />
          <h3 className="font-semibold">{sound.title}</h3>
        </div>
        <button
          onClick={togglePlay}
          className="neu-button p-3 text-accent"
          aria-label={isPlaying ? 'Pause' : 'Play'}
        >
          {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
        </button>
      </div>
      
      <p className="text-sm text-gray-600 mb-4">{sound.description}</p>
      
      <div className="flex items-center gap-3">
        <VolumeIcon className="h-4 w-4 text-accent" />
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={handleVolumeChange}
          className="flex-1"
        />
      </div>

      <audio
        ref={audioRef}
        src={sound.url}
        loop
        onEnded={handleAudioEnded}
        onError={handleAudioError}
        preload="none"
      />
    </div>
  );
};

const SoundGallery = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'noise' | 'nature' | 'meditation'>('all');

  const filteredSounds = sounds.filter(
    sound => activeCategory === 'all' || sound.category === activeCategory
  );

  return (
    <div className="space-y-8">
      <div className="neu-flat p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Sound Gallery</h1>
          <div className="flex gap-2">
            <button
              onClick={() => setActiveCategory('all')}
              className={`neu-button px-4 py-2 ${activeCategory === 'all' ? 'text-accent' : ''}`}
            >
              All
            </button>
            <button
              onClick={() => setActiveCategory('noise')}
              className={`neu-button px-4 py-2 ${activeCategory === 'noise' ? 'text-accent' : ''}`}
            >
              Noise Therapy
            </button>
            <button
              onClick={() => setActiveCategory('nature')}
              className={`neu-button px-4 py-2 ${activeCategory === 'nature' ? 'text-accent' : ''}`}
            >
              Nature
            </button>
            <button
              onClick={() => setActiveCategory('meditation')}
              className={`neu-button px-4 py-2 ${activeCategory === 'meditation' ? 'text-accent' : ''}`}
            >
              Meditation
            </button>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredSounds.map(sound => (
            <SoundPlayer key={sound.id} sound={sound} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default SoundGallery;