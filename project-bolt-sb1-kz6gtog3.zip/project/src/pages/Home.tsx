import React from 'react';
import { Play, Volume2 } from 'lucide-react';
import SubscribeForm from '../components/SubscribeForm';

const Home = () => {
  return (
    <div className="space-y-8">
      <div className="neu-flat p-8 text-center">
        <h1 className="text-4xl font-bold mb-4">Welcome to AcuFlow</h1>
        <p className="text-xl text-gray-600">Your personal tinnitus relief companion</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="neu-flat p-6 space-y-4">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <Volume2 className="text-accent" />
            Quick Relief
          </h2>
          <p>Start your tinnitus relief session with our most popular sounds:</p>
          <div className="grid grid-cols-2 gap-4">
            {['White Noise', 'Pink Noise', 'Brown Noise', 'Nature Sounds'].map((sound) => (
              <button
                key={sound}
                className="neu-button p-4 rounded-lg flex items-center justify-center gap-2 hover:text-accent"
              >
                <Play size={16} />
                {sound}
              </button>
            ))}
          </div>
        </div>

        <div className="neu-flat p-6">
          <SubscribeForm />
        </div>
      </div>
    </div>
  );
}

export default Home;