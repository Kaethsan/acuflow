import React, { useState } from 'react';
import { Utensils, Apple, Coffee, Leaf, ArrowLeft, Clock, Users, ChevronRight, Search, Filter, Bookmark, BookmarkCheck } from 'lucide-react';
import { useRecipeStore } from '../store/recipeStore';

interface Recipe {
  id: string;
  title: string;
  description: string;
  prepTime: string;
  servings: number;
  ingredients: string[];
  instructions: string[];
  nutritionFacts: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    magnesium: number;
    zinc: number;
  };
}

const recipes: Recipe[] = [
  {
    id: 'ginger-turmeric-tea',
    title: 'Anti-Inflammatory Ginger Turmeric Tea',
    description: 'A soothing tea blend that combines the anti-inflammatory properties of ginger and turmeric to help reduce inflammation and tinnitus symptoms.',
    prepTime: '10 minutes',
    servings: 2,
    ingredients: [
      '2 cups water',
      '1-inch piece fresh ginger, sliced',
      '1 teaspoon ground turmeric',
      '1/4 teaspoon black pepper',
      '1 tablespoon honey',
      '1 lemon, juiced',
      'Optional: 1/2 cup coconut milk'
    ],
    instructions: [
      'Bring water to a boil in a small saucepan',
      'Add ginger slices and simmer for 5 minutes',
      'Add turmeric and black pepper, simmer for 2 more minutes',
      'Strain into cups',
      'Add honey and lemon juice to taste',
      'Optional: Add coconut milk for a creamy golden latte'
    ],
    nutritionFacts: {
      calories: 45,
      protein: 0,
      carbs: 12,
      fat: 0,
      magnesium: 5,
      zinc: 0.1
    }
  },
  {
    id: 'potassium-rich-salad',
    title: 'Potassium-Rich Avocado Salad',
    description: 'A nutrient-dense salad packed with potassium and healthy fats, which may help regulate fluid balance and reduce tinnitus intensity.',
    prepTime: '15 minutes',
    servings: 2,
    ingredients: [
      '2 ripe avocados, diced',
      '2 medium sweet potatoes, roasted and cubed',
      '2 cups baby spinach',
      '1/2 cup cherry tomatoes, halved',
      '1/4 cup pumpkin seeds',
      '2 tablespoons olive oil',
      '1 tablespoon balsamic vinegar',
      'Sea salt and black pepper to taste'
    ],
    instructions: [
      'Arrange spinach on plates',
      'Top with diced avocado and roasted sweet potato',
      'Add cherry tomatoes',
      'Sprinkle with pumpkin seeds',
      'Drizzle with olive oil and balsamic vinegar',
      'Season with salt and pepper'
    ],
    nutritionFacts: {
      calories: 420,
      protein: 8,
      carbs: 32,
      fat: 28,
      magnesium: 120,
      zinc: 1.8
    }
  },
  {
    id: 'b12-breakfast',
    title: 'B12-Rich Breakfast Bowl',
    description: 'A hearty breakfast bowl rich in vitamin B12, which is essential for nerve health and may help manage tinnitus symptoms.',
    prepTime: '20 minutes',
    servings: 2,
    ingredients: [
      '4 eggs',
      '1 cup quinoa, cooked',
      '2 cups mushrooms, sautéed',
      '2 cups baby spinach',
      '1 avocado, sliced',
      '2 tablespoons nutritional yeast',
      '2 tablespoons olive oil',
      'Salt and pepper to taste'
    ],
    instructions: [
      'Cook quinoa according to package instructions',
      'Sauté mushrooms in olive oil until golden',
      'Poach or soft boil eggs to desired doneness',
      'Wilt spinach in the same pan as mushrooms',
      'Assemble bowls with quinoa as base',
      'Top with eggs, mushrooms, spinach, and avocado',
      'Sprinkle with nutritional yeast',
      'Season with salt and pepper'
    ],
    nutritionFacts: {
      calories: 480,
      protein: 22,
      carbs: 38,
      fat: 24,
      magnesium: 160,
      zinc: 2.5
    }
  },
  {
    id: 'zinc-rich-curry',
    title: 'Zinc-Rich Lentil Curry',
    description: 'A warming curry packed with zinc from lentils and pumpkin seeds, essential minerals that may help reduce tinnitus symptoms.',
    prepTime: '30 minutes',
    servings: 4,
    ingredients: [
      '2 cups red lentils',
      '1 onion, diced',
      '3 cloves garlic, minced',
      '1 tablespoon curry powder',
      '1 can coconut milk',
      '4 cups vegetable broth',
      '1/4 cup pumpkin seeds',
      '2 cups spinach',
      'Fresh cilantro for garnish'
    ],
    instructions: [
      'Rinse lentils until water runs clear',
      'Sauté onion and garlic until soft',
      'Add curry powder and cook until fragrant',
      'Add lentils, coconut milk, and broth',
      'Simmer for 20 minutes until lentils are tender',
      'Stir in spinach until wilted',
      'Top with pumpkin seeds and cilantro',
      'Serve hot'
    ],
    nutritionFacts: {
      calories: 380,
      protein: 18,
      carbs: 45,
      fat: 16,
      magnesium: 140,
      zinc: 3.2
    }
  },
  {
    id: 'magnesium-dinner',
    title: 'Magnesium-Rich Salmon Dinner',
    description: 'A complete dinner featuring salmon, rich in omega-3s and magnesium, paired with magnesium-rich sides to support nerve function.',
    prepTime: '25 minutes',
    servings: 2,
    ingredients: [
      '2 salmon fillets (6 oz each)',
      '2 cups Swiss chard, chopped',
      '1 cup brown rice',
      '1/4 cup almonds, sliced',
      '2 tablespoons olive oil',
      '1 lemon',
      '2 cloves garlic, minced',
      'Fresh herbs (dill, parsley)'
    ],
    instructions: [
      'Cook brown rice according to package instructions',
      'Season salmon with lemon, garlic, and herbs',
      'Bake salmon at 400°F for 12-15 minutes',
      'Sauté Swiss chard in olive oil with garlic',
      'Toast almonds until golden',
      'Serve salmon over rice with Swiss chard',
      'Top with toasted almonds and fresh herbs',
      'Squeeze fresh lemon over the dish'
    ],
    nutritionFacts: {
      calories: 520,
      protein: 42,
      carbs: 38,
      fat: 24,
      magnesium: 180,
      zinc: 2.8
    }
  }
];

interface FoodItem {
  title: string;
  description: string;
  benefits: string[];
  category: 'recommended' | 'avoid' | 'meal-planning';
}

const foodItems: FoodItem[] = [
  {
    title: 'Magnesium-Rich Foods',
    description: 'Leafy greens, nuts, seeds, and whole grains',
    benefits: ['Supports nerve function', 'May reduce tinnitus symptoms', 'Improves sleep quality'],
    category: 'recommended'
  },
  {
    title: 'Zinc-Rich Foods',
    description: 'Oysters, beef, pumpkin seeds',
    benefits: ['Supports immune system', 'May help with tinnitus', 'Essential for healing'],
    category: 'recommended'
  },
  {
    title: 'B-Vitamin Foods',
    description: 'Fish, eggs, dairy products',
    benefits: ['Supports nerve health', 'Improves energy levels', 'Essential for metabolism'],
    category: 'recommended'
  },
  {
    title: 'Omega-3 Rich Foods',
    description: 'Salmon, walnuts, flaxseeds',
    benefits: ['Anti-inflammatory properties', 'Supports brain health', 'May reduce tinnitus intensity'],
    category: 'recommended'
  },
  {
    title: 'Antioxidant-Rich Foods',
    description: 'Berries, dark chocolate, pecans',
    benefits: ['Protects against free radicals', 'Supports overall health', 'May help with circulation'],
    category: 'recommended'
  },
  {
    title: 'Caffeine',
    description: 'Coffee, tea, energy drinks',
    benefits: ['Can increase tinnitus symptoms', 'May cause anxiety', 'Affects sleep quality'],
    category: 'avoid'
  },
  {
    title: 'Salt',
    description: 'Processed foods, canned goods',
    benefits: ['Can affect blood pressure', 'May worsen tinnitus', 'Causes water retention'],
    category: 'avoid'
  },
  {
    title: 'Alcohol',
    description: 'All alcoholic beverages',
    benefits: ['Can increase tinnitus symptoms', 'Affects sleep quality', 'May cause dehydration'],
    category: 'avoid'
  },
  {
    title: 'Breakfast Ideas',
    description: 'Oatmeal with nuts, yogurt with berries',
    benefits: ['High in nutrients', 'Sustained energy', 'Easy to prepare'],
    category: 'meal-planning'
  },
  {
    title: 'Lunch Options',
    description: 'Quinoa bowls, salads with lean protein',
    benefits: ['Balanced nutrition', 'Light yet filling', 'Rich in vitamins'],
    category: 'meal-planning'
  },
  {
    title: 'Dinner Ideas',
    description: 'Grilled fish, steamed vegetables, whole grains',
    benefits: ['Protein-rich', 'Easy to digest', 'Nutrient-dense'],
    category: 'meal-planning'
  }
];

const Nutrition = () => {
  const { savedRecipes, saveRecipe, removeRecipe } = useRecipeStore();
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sectionSearchQueries, setSectionSearchQueries] = useState({
    recommended: '',
    avoid: '',
    recipes: '',
    planning: ''
  });
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'recipes' | 'foods' | 'planning'>('all');

  const isRecipeSaved = (recipeId: string) => {
    return savedRecipes.some(recipe => recipe.id === recipeId);
  };

  const toggleSaveRecipe = (recipe: Recipe) => {
    if (isRecipeSaved(recipe.id)) {
      removeRecipe(recipe.id);
    } else {
      saveRecipe({
        id: recipe.id,
        title: recipe.title,
        description: recipe.description,
        prepTime: recipe.prepTime,
        servings: recipe.servings
      });
    }
  };

  const handleSectionSearch = (section: keyof typeof sectionSearchQueries, value: string) => {
    setSectionSearchQueries(prev => ({
      ...prev,
      [section]: value
    }));
  };

  const filterItemsBySection = (items: FoodItem[], section: string) => {
    const searchQuery = sectionSearchQueries[section as keyof typeof sectionSearchQueries];
    return items.filter(item =>
      searchQuery === '' || (
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.benefits.some(benefit =>
          benefit.toLowerCase().includes(searchQuery.toLowerCase())
        )
      )
    );
  };

  const renderSectionSearch = (section: keyof typeof sectionSearchQueries) => (
    <div className="flex items-center gap-2 mb-4">
      <div className="relative flex-1">
        <input
          type="text"
          placeholder={`Search ${section}...`}
          value={sectionSearchQueries[section]}
          onChange={(e) => handleSectionSearch(section, e.target.value)}
          className="w-full p-3 pl-10 neu-pressed rounded-lg"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-accent h-5 w-5" />
      </div>
      <button
        onClick={() => handleSectionSearch(section, sectionSearchQueries[section])}
        className="neu-button p-3 text-accent"
      >
        <Search className="h-5 w-5" />
      </button>
    </div>
  );

  const renderFoodList = (items: FoodItem[], title: string, icon: React.ReactNode, section: keyof typeof sectionSearchQueries) => (
    <div className="neu-pressed p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        {icon}
        {title}
      </h2>
      {renderSectionSearch(section)}
      <div className="h-[400px] overflow-y-auto pr-4 space-y-3">
        {filterItemsBySection(items, section).map((item, index) => (
          <div key={index} className="neu-flat p-4">
            <h3 className="font-semibold">{item.title}</h3>
            <p className="text-sm text-gray-600 mt-2">{item.description}</p>
            <div className="mt-3 space-y-1">
              {item.benefits.map((benefit, i) => (
                <p key={i} className="text-sm flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-accent"></div>
                  {benefit}
                </p>
              ))}
            </div>
          </div>
        ))}
        {filterItemsBySection(items, section).length === 0 && (
          <div className="neu-flat p-4 text-center">
            <p className="text-gray-600">No items found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderRecipeList = () => (
    <div className="space-y-4">
      {renderSectionSearch('recipes')}
      {recipes
        .filter(recipe =>
          sectionSearchQueries.recipes === '' || (
            recipe.title.toLowerCase().includes(sectionSearchQueries.recipes.toLowerCase()) ||
            recipe.description.toLowerCase().includes(sectionSearchQueries.recipes.toLowerCase()) ||
            recipe.ingredients.some(ingredient =>
              ingredient.toLowerCase().includes(sectionSearchQueries.recipes.toLowerCase())
            )
          )
        )
        .map(recipe => (
          <div key={recipe.id} className="neu-flat p-4">
            <div className="flex justify-between items-start">
              <button
                onClick={() => setSelectedRecipe(recipe)}
                className="flex-1 text-left group"
              >
                <h3 className="font-semibold group-hover:text-accent transition-colors">
                  {recipe.title}
                </h3>
                <p className="text-sm text-gray-600 mt-1">{recipe.description}</p>
                <div className="flex items-center gap-4 mt-2">
                  <span className="text-sm text-accent flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {recipe.prepTime}
                  </span>
                  <span className="text-sm text-accent flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    {recipe.servings} servings
                  </span>
                </div>
              </button>
              <button
                onClick={() => toggleSaveRecipe(recipe)}
                className={`neu-button p-2 ml-4 ${isRecipeSaved(recipe.id) ? 'text-accent' : ''} hover:text-accent active:neu-pressed`}
                title={isRecipeSaved(recipe.id) ? 'Remove from saved recipes' : 'Save recipe'}
              >
                {isRecipeSaved(recipe.id) ? (
                  <BookmarkCheck className="h-5 w-5" />
                ) : (
                  <Bookmark className="h-5 w-5" />
                )}
              </button>
            </div>
          </div>
        ))}
    </div>
  );

  const renderRecipeDetails = (recipe: Recipe) => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setSelectedRecipe(null)}
            className="neu-button p-3 text-accent"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h2 className="text-2xl font-semibold">{recipe.title}</h2>
        </div>
        <button
          onClick={() => toggleSaveRecipe(recipe)}
          className={`neu-button p-3 ${isRecipeSaved(recipe.id) ? 'text-accent' : ''} hover:text-accent active:neu-pressed`}
          title={isRecipeSaved(recipe.id) ? 'Remove from saved recipes' : 'Save recipe'}
        >
          {isRecipeSaved(recipe.id) ? (
            <BookmarkCheck className="h-5 w-5" />
          ) : (
            <Bookmark className="h-5 w-5" />
          )}
        </button>
      </div>

      <div className="neu-pressed p-6">
        <p className="text-gray-600 mb-6">{recipe.description}</p>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="neu-flat p-4 flex items-center gap-3">
            <Clock className="text-accent" />
            <div>
              <p className="text-sm text-gray-600">Prep Time</p>
              <p className="font-semibold">{recipe.prepTime}</p>
            </div>
          </div>
          <div className="neu-flat p-4 flex items-center gap-3">
            <Users className="text-accent" />
            <div>
              <p className="text-sm text-gray-600">Servings</p>
              <p className="font-semibold">{recipe.servings}</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-3">Ingredients</h3>
            <ul className="space-y-2">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="neu-flat p-3 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                  {ingredient}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3">Instructions</h3>
            <ol className="space-y-3">
              {recipe.instructions.map((instruction, index) => (
                <li key={index} className="neu-flat p-4">
                  <span className="font-semibold text-accent mr-2">{index + 1}.</span>
                  {instruction}
                </li>
              ))}
            </ol>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3">Nutrition Facts</h3>
            <div className="neu-flat p-4 grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-600">Calories</p>
                <p className="font-semibold">{recipe.nutritionFacts.calories} kcal</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Protein</p>
                <p className="font-semibold">{recipe.nutritionFacts.protein}g</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Carbs</p>
                <p className="font-semibold">{recipe.nutritionFacts.carbs}g</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Fat</p>
                <p className="font-semibold">{recipe.nutritionFacts.fat}g</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Magnesium</p>
                <p className="font-semibold">{recipe.nutritionFacts.magnesium}mg</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Zinc</p>
                <p className="font-semibold">{recipe.nutritionFacts.zinc}mg</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderGlobalSearch = () => (
    <div className="flex items-center gap-4 mb-8">
      <div className="relative flex-1">
        <input
          type="text"
          placeholder="Search recipes, foods, and meal plans..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full p-4 pl-12 neu-pressed rounded-lg"
        />
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-accent h-5 w-5" />
      </div>
      <div className="flex gap-2">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`neu-button p-3 ${selectedCategory === 'all' ? 'text-accent' : ''}`}
        >
          All
        </button>
        <button
          onClick={() => setSelectedCategory('recipes')}
          className={`neu-button p-3 ${selectedCategory === 'recipes' ? 'text-accent' : ''}`}
        >
          Recipes
        </button>
        <button
          onClick={() => setSelectedCategory('foods')}
          className={`neu-button p-3 ${selectedCategory === 'foods' ? 'text-accent' : ''}`}
        >
          Foods
        </button>
        <button
          onClick={() => setSelectedCategory('planning')}
          className={`neu-button p-3 ${selectedCategory === 'planning' ? 'text-accent' : ''}`}
        >
          Planning
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      <div className="neu-flat p-8">
        {selectedRecipe ? (
          renderRecipeDetails(selectedRecipe)
        ) : (
          <>
            <h1 className="text-3xl font-bold mb-6 flex items-center justify-between">
              Nutrition Guide
              <Filter className="text-accent h-6 w-6" />
            </h1>
            
            {renderGlobalSearch()}
            
            <div className="grid md:grid-cols-2 gap-8">
              {(selectedCategory === 'all' || selectedCategory === 'foods') && (
                <>
                  {renderFoodList(
                    foodItems.filter(item => item.category === 'recommended'),
                    'Recommended Foods',
                    <Apple className="text-accent" />,
                    'recommended'
                  )}
                  {renderFoodList(
                    foodItems.filter(item => item.category === 'avoid'),
                    'Foods to Avoid',
                    <Coffee className="text-accent" />,
                    'avoid'
                  )}
                </>
              )}

              {(selectedCategory === 'all' || selectedCategory === 'recipes') && (
                <div className="neu-pressed p-6">
                  <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <Leaf className="text-accent" />
                    Healthy Recipes
                  </h2>
                  <div className="h-[400px] overflow-y-auto pr-4">
                    {renderRecipeList()}
                  </div>
                </div>
              )}

              {(selectedCategory === 'all' || selectedCategory === 'planning') && (
                renderFoodList(
                  foodItems.filter(item => item.category === 'meal-planning'),
                  'Meal Planning',
                  <Utensils className="text-accent" />,
                  'planning'
                )
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Nutrition;