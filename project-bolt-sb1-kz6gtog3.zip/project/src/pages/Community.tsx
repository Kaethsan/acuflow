import React, { useState } from 'react';
import { MessageSquare, Heart, Share2, Users, Star, Award, Lightbulb, ArrowLeft } from 'lucide-react';

interface Story {
  id: string;
  author: string;
  experience: string;
  content: string;
  image: string;
  likes: number;
  isLiked: boolean;
}

interface GroupPost {
  id: string;
  author: string;
  content: string;
  date: string;
  likes: number;
  replies: number;
}

const Community = () => {
  const [activeGroup, setActiveGroup] = useState<string | null>(null);
  const [stories, setStories] = useState<Story[]>([
    {
      id: '1',
      author: 'Sarah Mitchell',
      experience: '3 years with tinnitus',
      content: "After trying various treatments, I found that a combination of sound therapy and meditation has helped me tremendously. Don't lose hope!",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
      likes: 24,
      isLiked: false
    },
    {
      id: '2',
      author: 'David Cooper',
      experience: '5 years with tinnitus',
      content: "Finding this community changed everything. Sharing experiences and tips with others who understand has been incredibly therapeutic.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
      likes: 18,
      isLiked: false
    }
  ]);

  const groups = {
    newcomers: {
      id: 'newcomers',
      title: 'Newcomers Circle',
      description: 'Connect with others who are just starting their journey.',
      icon: Users,
      posts: [
        {
          id: '1',
          author: 'Emily White',
          content: 'Just diagnosed with tinnitus last week. Any tips for sleeping better?',
          date: '2 hours ago',
          likes: 5,
          replies: 3
        },
        {
          id: '2',
          author: 'James Wilson',
          content: 'Found this great white noise app that really helps mask the ringing.',
          date: '5 hours ago',
          likes: 8,
          replies: 6
        }
      ]
    },
    success: {
      id: 'success',
      title: 'Success Stories',
      description: 'Share and celebrate progress and victories together.',
      icon: Award,
      posts: [
        {
          id: '1',
          author: 'Michael Brown',
          content: 'After 6 months of consistent sound therapy, my tinnitus is much more manageable!',
          date: '1 day ago',
          likes: 15,
          replies: 8
        },
        {
          id: '2',
          author: 'Lisa Chen',
          content: "Meditation has been a game-changer for me. Here\\'s my daily routine...",
          date: '2 days ago',
          likes: 12,
          replies: 5
        }
      ]
    },
    tips: {
      id: 'tips',
      title: 'Tips & Tricks',
      description: 'Exchange practical advice and coping strategies.',
      icon: Lightbulb,
      posts: [
        {
          id: '1',
          author: 'Dr. Sarah Johnson',
          content: 'Pro tip: Keep a tinnitus diary to identify your triggers.',
          date: '3 hours ago',
          likes: 20,
          replies: 12
        },
        {
          id: '2',
          author: 'Mark Davis',
          content: 'Here\'s a breathing exercise that helps during loud episodes...',
          date: '1 day ago',
          likes: 16,
          replies: 9
        }
      ]
    }
  };

  const toggleLike = (storyId: string) => {
    setStories(stories.map(story => {
      if (story.id === storyId) {
        return {
          ...story,
          likes: story.isLiked ? story.likes - 1 : story.likes + 1,
          isLiked: !story.isLiked
        };
      }
      return story;
    }));
  };

  const renderGroupContent = (groupId: string) => {
    const group = groups[groupId as keyof typeof groups];
    
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveGroup(null)}
            className="neu-button p-3 text-accent"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h2 className="text-2xl font-semibold">{group.title}</h2>
        </div>

        <div className="neu-pressed p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold">Discussion</h3>
            <button className="neu-button p-3 text-accent">
              <MessageSquare className="h-5 w-5" />
            </button>
          </div>

          <div className="space-y-4">
            {group.posts.map((post) => (
              <div key={post.id} className="neu-flat p-6">
                <div className="flex justify-between mb-2">
                  <span className="font-semibold">{post.author}</span>
                  <span className="text-sm text-gray-600">{post.date}</span>
                </div>
                <p className="mb-4">{post.content}</p>
                <div className="flex items-center gap-4">
                  <button className="neu-button p-2 text-accent flex items-center gap-2">
                    <Heart className="h-4 w-4" />
                    {post.likes}
                  </button>
                  <button className="neu-button p-2 text-accent flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    {post.replies}
                  </button>
                  <button className="neu-button p-2 text-accent">
                    <Share2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  if (activeGroup) {
    return (
      <div className="space-y-8">
        <div className="neu-flat p-8">
          {renderGroupContent(activeGroup)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="neu-flat p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Tinnitus Community</h1>
          <button className="neu-button p-4 text-accent hover:text-primary-dark transition-colors">
            <MessageSquare className="h-6 w-6" />
          </button>
        </div>

        {/* Featured Stories */}
        <div className="neu-pressed p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Star className="text-accent" />
            Featured Stories
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {stories.map((story) => (
              <div key={story.id} className="neu-flat p-6">
                <div className="flex items-center gap-3 mb-4">
                  <img
                    src={story.image}
                    alt="Profile"
                    className="w-12 h-12 rounded-full object-cover neu-pressed"
                  />
                  <div>
                    <h3 className="font-semibold">{story.author}</h3>
                    <p className="text-sm text-gray-600">{story.experience}</p>
                  </div>
                </div>
                <p className="mb-4">{story.content}</p>
                <div className="flex items-center gap-4">
                  <button 
                    className={`neu-button p-2 flex items-center gap-2 transition-colors ${
                      story.isLiked ? 'text-red-500' : 'text-accent hover:text-primary-dark'
                    }`}
                    onClick={() => toggleLike(story.id)}
                  >
                    <Heart className={`h-5 w-5 ${story.isLiked ? 'fill-current' : ''}`} />
                    <span>{story.likes}</span>
                  </button>
                  <button className="neu-button p-2 text-accent hover:text-primary-dark transition-colors">
                    <Share2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Support Groups */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(groups).map(([id, group]) => {
            const Icon = group.icon;
            return (
              <div key={id} className="neu-pressed p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Icon className="text-accent" />
                  {group.title}
                </h2>
                <p className="mb-4">{group.description}</p>
                <button 
                  className="w-full neu-button p-3 text-accent hover:text-primary-dark transition-colors"
                  onClick={() => setActiveGroup(id)}
                >
                  Join Discussion
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Community;