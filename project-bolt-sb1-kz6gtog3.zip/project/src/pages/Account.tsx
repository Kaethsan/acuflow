import React, { useState } from 'react';
import { User, Settings, Bell, Shield, Volume2, Calendar, Download, Upload, Moon, Sun, LogOut, Crown, AlertCircle, ArrowLeft } from 'lucide-react';
import { useThemeStore } from '../store/themeStore';
import { useAuthStore } from '../store/authStore';
import LoginForm from '../components/LoginForm';
import { Link, useNavigate } from 'react-router-dom';

const Account = () => {
  const navigate = useNavigate();
  const { isDark, toggleTheme } = useThemeStore();
  const { isLoggedIn, logout } = useAuthStore();
  const [name, setName] = useState('Sandra Kaethner');
  const [email, setEmail] = useState('sandrakaethner@gmail.com');
  const [notifications, setNotifications] = useState({
    dailyReminders: true,
    weeklyReports: true,
    newContent: false,
    communityUpdates: true
  });
  const [preferences, setPreferences] = useState({
    language: 'English',
    volume: 75,
    autoplay: true
  });
  const [showCancelDialog, setShowCancelDialog] = useState(false);

  if (!isLoggedIn) {
    return <LoginForm />;
  }

  return (
    <div className="space-y-8">
      <div className="neu-flat p-8">
        {/* Header with Back Button */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate(-1)}
            className="neu-button p-3 text-accent"
            aria-label="Go back"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center justify-between flex-1">
            <div className="flex items-center gap-4">
              <div className="neu-pressed w-16 h-16 rounded-full overflow-hidden flex-shrink-0">
                <img
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330"
                  alt="Sandra Kaethner"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h1 className="text-3xl font-bold">{name}</h1>
                <p className="text-gray-600">{email}</p>
              </div>
            </div>
            <button
              onClick={logout}
              className="neu-button p-3 text-accent"
              title="Sign out"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="space-y-8">
          {/* Profile Information */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <User className="text-accent" />
              Profile Information
            </h2>
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1">
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full p-3 neu-pressed rounded-lg"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full p-3 neu-pressed rounded-lg"
                  />
                </div>
              </div>
              <button className="neu-button px-6 py-2 text-accent">
                Save Changes
              </button>
            </div>
          </div>

          {/* Notifications section */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Bell className="text-accent" />
              Notifications
            </h2>
            <div className="grid md:grid-cols-2 gap-4">
              <label className="flex items-center gap-3 neu-flat p-4">
                <input
                  type="checkbox"
                  checked={notifications.dailyReminders}
                  onChange={(e) => setNotifications({...notifications, dailyReminders: e.target.checked})}
                  className="neu-pressed"
                />
                <div>
                  <p className="font-medium">Daily Reminders</p>
                  <p className="text-sm text-gray-600">Get daily meditation reminders</p>
                </div>
              </label>
              <label className="flex items-center gap-3 neu-flat p-4">
                <input
                  type="checkbox"
                  checked={notifications.weeklyReports}
                  onChange={(e) => setNotifications({...notifications, weeklyReports: e.target.checked})}
                  className="neu-pressed"
                />
                <div>
                  <p className="font-medium">Weekly Reports</p>
                  <p className="text-sm text-gray-600">Receive progress summaries</p>
                </div>
              </label>
              <label className="flex items-center gap-3 neu-flat p-4">
                <input
                  type="checkbox"
                  checked={notifications.newContent}
                  onChange={(e) => setNotifications({...notifications, newContent: e.target.checked})}
                  className="neu-pressed"
                />
                <div>
                  <p className="font-medium">New Content</p>
                  <p className="text-sm text-gray-600">Updates about new sounds and features</p>
                </div>
              </label>
              <label className="flex items-center gap-3 neu-flat p-4">
                <input
                  type="checkbox"
                  checked={notifications.communityUpdates}
                  onChange={(e) => setNotifications({...notifications, communityUpdates: e.target.checked})}
                  className="neu-pressed"
                />
                <div>
                  <p className="font-medium">Community Updates</p>
                  <p className="text-sm text-gray-600">Stay connected with the community</p>
                </div>
              </label>
            </div>
          </div>

          {/* App Preferences */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Settings className="text-accent" />
              App Preferences
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">Language</label>
                <select
                  value={preferences.language}
                  onChange={(e) => setPreferences({...preferences, language: e.target.value})}
                  className="w-full p-3 neu-pressed rounded-lg"
                >
                  <option>English</option>
                  <option>Deutsch</option>
                  <option>Español</option>
                  <option>Français</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Theme</label>
                <div className="flex gap-4">
                  <button
                    className={`flex-1 neu-button p-3 flex items-center justify-center gap-2 ${
                      !isDark ? 'text-accent' : ''
                    }`}
                    onClick={() => {
                      if (isDark) toggleTheme();
                    }}
                  >
                    <Sun className="h-5 w-5" />
                    Light
                  </button>
                  <button
                    className={`flex-1 neu-button p-3 flex items-center justify-center gap-2 ${
                      isDark ? 'text-accent' : ''
                    }`}
                    onClick={() => {
                      if (!isDark) toggleTheme();
                    }}
                  >
                    <Moon className="h-5 w-5" />
                    Dark
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Default Volume</label>
                <div className="flex items-center gap-4">
                  <Volume2 className="text-accent" />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={preferences.volume}
                    onChange={(e) => setPreferences({...preferences, volume: Number(e.target.value)})}
                    className="flex-1"
                  />
                  <span className="w-12 text-right">{preferences.volume}%</span>
                </div>
              </div>
              <div>
                <label className="flex items-center gap-3 neu-flat p-4">
                  <input
                    type="checkbox"
                    checked={preferences.autoplay}
                    onChange={(e) => setPreferences({...preferences, autoplay: e.target.checked})}
                    className="neu-pressed"
                  />
                  <div>
                    <p className="font-medium">Autoplay Sounds</p>
                    <p className="text-sm text-gray-600">Start playing automatically</p>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Subscription Management */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Crown className="text-accent" />
              Subscription Management
            </h2>
            <div className="neu-flat p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold">Premium Plan</h3>
                  <p className="text-sm text-gray-600">Active until March 24, 2025</p>
                </div>
                <span className="text-accent font-semibold">$19.99/month</span>
              </div>
              <div className="flex gap-4">
                <Link 
                  to="/subscription" 
                  className="neu-button px-6 py-2 text-accent flex items-center gap-2"
                >
                  <Crown className="h-4 w-4" />
                  Change Plan
                </Link>
                <button 
                  onClick={() => setShowCancelDialog(true)}
                  className="neu-button px-6 py-2 text-accent hover:text-red-500 transition-colors"
                >
                  Cancel Subscription
                </button>
              </div>
            </div>

            {/* Cancel Subscription Dialog */}
            {showCancelDialog && (
              <div className="neu-flat p-6">
                <div className="flex items-center gap-3 mb-4 text-red-500">
                  <AlertCircle className="h-6 w-6" />
                  <h3 className="text-lg font-semibold">Cancel Subscription?</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Are you sure you want to cancel your Premium subscription? You'll lose access to premium features at the end of your current billing period.
                </p>
                <div className="flex gap-4">
                  <button 
                    onClick={() => setShowCancelDialog(false)}
                    className="flex-1 neu-button p-3"
                  >
                    Keep Subscription
                  </button>
                  <button 
                    onClick={() => {
                      // Handle cancellation logic here
                      setShowCancelDialog(false);
                    }}
                    className="flex-1 neu-button p-3 text-red-500"
                  >
                    Confirm Cancellation
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Privacy & Security */}
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Shield className="text-accent" />
              Privacy & Security
            </h2>
            <div className="space-y-4">
              <button className="w-full neu-button p-4 text-left flex items-center justify-between">
                <span>Change Password</span>
                <Shield className="h-5 w-5" />
              </button>
              <button className="w-full neu-button p-4 text-left flex items-center justify-between">
                <span>Two-Factor Authentication</span>
                <Shield className="h-5 w-5" />
              </button>
              <button className="w-full neu-button p-4 text-left flex items-center justify-between">
                <span>Download My Data</span>
                <Download className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;