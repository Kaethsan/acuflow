import React from 'react';
import { BookOpen, Calendar, Settings } from 'lucide-react';

const Dashboard = () => {
  return (
    <div className="space-y-8">
      <div className="neu-flat p-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Personal Dashboard</h1>
            <p className="text-gray-600">Welcome to AcuFlow</p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Calendar className="text-accent" />
              Today's Stats
            </h2>
            <div className="space-y-4">
              <div className="neu-flat p-4">
                <p className="font-semibold">Meditation Time</p>
                <p className="text-2xl text-accent">45 minutes</p>
              </div>
              <div className="neu-flat p-4">
                <p className="font-semibold">Sound Therapy</p>
                <p className="text-2xl text-accent">2 sessions</p>
              </div>
            </div>
          </div>

          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <BookOpen className="text-accent" />
              Progress
            </h2>
            <div className="space-y-4">
              <div className="neu-flat p-4">
                <p className="font-semibold">Weekly Goal</p>
                <div className="w-full bg-primary-dark rounded-full h-2 mt-2">
                  <div className="bg-accent w-3/4 h-2 rounded-full"></div>
                </div>
              </div>
              <div className="neu-flat p-4">
                <p className="font-semibold">Streak</p>
                <p className="text-2xl text-accent">5 days</p>
              </div>
            </div>
          </div>

          <div className="neu-pressed p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Settings className="text-accent" />
              Quick Actions
            </h2>
            <div className="space-y-4">
              <button className="w-full neu-button p-3 text-accent hover:text-primary-dark">
                Start Session
              </button>
              <button className="w-full neu-button p-3 text-accent hover:text-primary-dark">
                View History
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;