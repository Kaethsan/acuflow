import React, { useState } from 'react';
import { Crown, Check, X, CreditCard, ArrowRight } from 'lucide-react';

interface SubscriptionDetails {
  name: string;
  email: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
}

const Subscription = () => {
  const [selectedPlan, setSelectedPlan] = useState<'pro' | 'premium' | null>(null);
  const [step, setStep] = useState<'plans' | 'details' | 'confirmation'>('plans');
  const [subscriptionDetails, setSubscriptionDetails] = useState<SubscriptionDetails>({
    name: '',
    email: '',
    cardNumber: '',
    expiryDate: '',
    cvv: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSubscriptionDetails(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('confirmation');
  };

  const renderSubscriptionDetails = () => (
    <div className="neu-flat p-8">
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => setStep('plans')}
          className="neu-button p-3 text-accent"
        >
          <X className="h-5 w-5" />
        </button>
        <h2 className="text-2xl font-semibold">
          Subscribe to {selectedPlan === 'pro' ? 'Pro' : 'Premium'}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="neu-pressed p-6">
          <h3 className="text-xl font-semibold mb-6">Personal Information</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Full Name</label>
              <input
                type="text"
                name="name"
                value={subscriptionDetails.name}
                onChange={handleInputChange}
                required
                className="w-full p-3 neu-pressed rounded-lg"
                placeholder="John Doe"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <input
                type="email"
                name="email"
                value={subscriptionDetails.email}
                onChange={handleInputChange}
                required
                className="w-full p-3 neu-pressed rounded-lg"
                placeholder="john@example.com"
              />
            </div>
          </div>
        </div>

        <div className="neu-pressed p-6">
          <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
            <CreditCard className="text-accent" />
            Payment Details
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Card Number</label>
              <input
                type="text"
                name="cardNumber"
                value={subscriptionDetails.cardNumber}
                onChange={handleInputChange}
                required
                className="w-full p-3 neu-pressed rounded-lg"
                placeholder="1234 5678 9012 3456"
                maxLength={19}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Expiry Date</label>
                <input
                  type="text"
                  name="expiryDate"
                  value={subscriptionDetails.expiryDate}
                  onChange={handleInputChange}
                  required
                  className="w-full p-3 neu-pressed rounded-lg"
                  placeholder="MM/YY"
                  maxLength={5}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">CVV</label>
                <input
                  type="text"
                  name="cvv"
                  value={subscriptionDetails.cvv}
                  onChange={handleInputChange}
                  required
                  className="w-full p-3 neu-pressed rounded-lg"
                  placeholder="123"
                  maxLength={3}
                />
              </div>
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="w-full neu-button p-4 text-accent flex items-center justify-center gap-2"
        >
          <span>Complete Subscription</span>
          <ArrowRight className="h-5 w-5" />
        </button>
      </form>
    </div>
  );

  const renderConfirmation = () => (
    <div className="neu-flat p-8 text-center">
      <div className="mb-8">
        <div className="w-16 h-16 mx-auto mb-4 neu-pressed rounded-full flex items-center justify-center">
          <Check className="h-8 w-8 text-accent" />
        </div>
        <h2 className="text-2xl font-semibold mb-2">Thank You!</h2>
        <p className="text-gray-600">
          Your subscription to {selectedPlan === 'pro' ? 'Pro' : 'Premium'} has been activated
        </p>
      </div>
      <button
        onClick={() => {
          setStep('plans');
          setSelectedPlan(null);
        }}
        className="neu-button px-6 py-3 text-accent"
      >
        Return to Plans
      </button>
    </div>
  );

  const renderPlans = () => (
    <div className="neu-flat p-8">
      <h1 className="text-3xl font-bold mb-6">Choose Your Plan</h1>
      
      <div className="grid md:grid-cols-3 gap-8">
        <div className="neu-pressed p-6 flex flex-col">
          <h2 className="text-xl font-semibold mb-4">Free</h2>
          <p className="text-3xl font-bold mb-4">$0<span className="text-sm font-normal">/month</span></p>
          <ul className="space-y-3 flex-grow">
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Basic sound library
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Limited daily sessions
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Basic articles access
            </li>
          </ul>
          <button className="w-full neu-button mt-6 py-2 text-accent">
            Current Plan
          </button>
        </div>

        <div className="neu-flat p-6 relative flex flex-col">
          <Crown className="text-accent absolute -top-4 right-4" size={24} />
          <h2 className="text-xl font-semibold mb-4">Pro</h2>
          <p className="text-3xl font-bold mb-4">$9.99<span className="text-sm font-normal">/month</span></p>
          <ul className="space-y-3 flex-grow">
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Full sound library
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Unlimited sessions
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Premium articles
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Custom sound mixing
            </li>
          </ul>
          <button
            onClick={() => {
              setSelectedPlan('pro');
              setStep('details');
            }}
            className="w-full neu-button mt-6 py-2 text-accent hover:text-primary-dark transition-colors"
          >
            Upgrade to Pro
          </button>
        </div>

        <div className="neu-pressed p-6 flex flex-col">
          <h2 className="text-xl font-semibold mb-4">Premium</h2>
          <p className="text-3xl font-bold mb-4">$19.99<span className="text-sm font-normal">/month</span></p>
          <ul className="space-y-3 flex-grow">
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Everything in Pro
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Personal consultation
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Priority support
            </li>
            <li className="flex items-center gap-2">
              <Check className="text-accent" size={16} />
              Exclusive content
            </li>
          </ul>
          <button
            onClick={() => {
              setSelectedPlan('premium');
              setStep('details');
            }}
            className="w-full neu-button mt-6 py-2 text-accent hover:text-primary-dark transition-colors"
          >
            Go Premium
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {step === 'plans' && renderPlans()}
      {step === 'details' && renderSubscriptionDetails()}
      {step === 'confirmation' && renderConfirmation()}
    </div>
  );
};

export default Subscription;