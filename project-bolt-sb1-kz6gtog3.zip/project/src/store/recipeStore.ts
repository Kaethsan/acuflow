import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface SavedRecipe {
  id: string;
  title: string;
  description: string;
  prepTime: string;
  servings: number;
}

interface RecipeState {
  savedRecipes: SavedRecipe[];
  saveRecipe: (recipe: SavedRecipe) => void;
  removeRecipe: (id: string) => void;
}

export const useRecipeStore = create<RecipeState>()(
  persist(
    (set) => ({
      savedRecipes: [],
      saveRecipe: (recipe) =>
        set((state) => ({
          savedRecipes: [...state.savedRecipes, recipe],
        })),
      removeRecipe: (id) =>
        set((state) => ({
          savedRecipes: state.savedRecipes.filter((recipe) => recipe.id !== id),
        })),
    }),
    {
      name: 'recipe-storage',
    }
  )
);